
::=======================
:: (1) Model condensation 
::=======================
   
 Tablo -sti gtapv7.sti
    if errorlevel 1 goto error

::=======================
:: (2) Create  *.exe file 
::=======================
	
 LTG gtapv7
    if errorlevel 1 goto error

echo Job Done      
goto endOK          

:error               
dir/od *.log         
echo PROBLEM !!!! examine most recent Log
:endOK

