
::  ====================================================================
rem rungtapv7.bat: Batch file to run GTAP model outside of RunGTAP
rem In DOS, type: rungtapv7
::  ====================================================================

::  ------------------------
rem (1) Numeraire simulation
::  ------------------------
 gtapv7 -cmf gtapv7.cmf
 if errorlevel 1 goto error

::=========================
:: (2) Global tariff elimination
::=========================
 gtapv7 -cmf GTarElim.cmf
 if errorlevel 1 goto error

goto Model solved, see results...
:error
ECHO  ERROR -- see log file...
:endbat
