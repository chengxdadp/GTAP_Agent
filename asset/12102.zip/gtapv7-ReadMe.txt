
=================================================================================
                     Standard GTAP model version 7 (GTAPv7)                              
=================================================================================
File: gtapv7.zip
Description: 
 This zip file contains the GEMPACK-based code of the GTAPv7 model and files to 
 run GTAP model simulations outside of RunGTAP.

 The theory behind the standard GTAP model is described in:   
    Erwin L. Corong, Thomas W. Hertel, Robert A. McDougall, Marinos E. Tsigas, 
    and Dominique van der Mensbrugghe. The Standard GTAP Model, Version 7. 
    Journal of Global Economic Analysis, [S.l.], v.2, n.1, p. 1-119, june 2017. 
    Available at: https://jgea.org/ojs/index.php/jgea/article/view/47
			  or  dx.doi.org/10.21642/JGEA.020101AF.

----------------
zip file summary
----------------
(A) Model-related (GEMPACK) files:
    (A1) GTAPv7.tab     - model code
    (A2) GTAPv7.sti     - condensation file
    (A3) GTAPv7.axs     - auxilliary statement file
    (A4) GTAPv7.axt     - auxilliary table file    
    (A5) GTAPv7.exe     - model executable file
    (A6) GTAPv7.cmf     - command (closure and shocks) file for numeráire simulation 
    (A7) GTarElim.cmf   - command (closure and shocks) file for global tariff elimination
	
(B) List of data files (Aggregated GTAP11a data with 2017 base year):
    (B1) Diagonal 'make' matrix (10 activities x 10 commodities x 10 regions) 
	     - Basedata10x10.har 
         - Sets-10x10.har
     	 - Default-10x10.prm

(C) Model simulation (DOS/batch) file
    (C1) RunGTAPv7.bat

(D) Model compilation: 
    - CompileGTAPv7.bat (If needed, execute this file to compile the GTAPv7 
      model. Warning: Requires Intel or GFortran compiler and source code 
      GEMPACK)

-------------------
Running simulations
-------------------
(E) To run simulations:
    (E1) Open a cmf file (e.g., GTAPv7.cmf or GTarElim.cmf)
    (E2) Open a DOS Box 
         - In TABmate: click Programs, then select DOS command prompt
         - Then, in the DOS box, type: rungtapv7.bat 
    (E3) Verify (in the DOS box) that the simulation run has completed 
         without error, or look at the log file (e.g., gtapv7.log or 
         GTarElim.log)
    (E4) Open the results files
         - Solution files (*.sl4):
           - Price homogeneity (numeraire) simulation: gtapv7.sl4  
           - Global tariff elimination simulation: GTarElim.sl4
         - Welfare decomposition (*-WEL.HAR):
           - Global tariff elimination simulation: GTarElim-WEL.har
